import itertools as it
import os
from pathlib import Path
from plot_fio_comon import *
import subprocess
import sys
import tempfile

root_dir = os.getcwd()

data_dir = os.path.join(root_dir, "data", "driver")
plot_dir = os.path.join(root_dir, "fig")

csv_name = "data_corun_io_comp"
input_csv = os.path.join(data_dir, csv_name + ".csv")

# baselines = [psync, io_uring, spdk, aeolia]
baselines = [psync, io_uring, spdk, aeolia]
for idx, base in enumerate(baselines, start=0):
    base.id = idx

data_files = []

# For I/O-compute corun
data_files.append(input_csv)

# For I/O-I/O corun
csv_name = "data_corun_io_io"
input_csv = os.path.join(data_dir, csv_name + ".csv")
data_files.append(input_csv)

env = {
    key: value.format(
        target=target,
    )
    for key, value in base_env.items()
}

# Preset
width = 4.8
height = 1.6
file_name = output_name(__file__)
output = os.path.join(plot_dir, file_name)

# MP Layout
mp_layout = MPLayout(
    mp_startx=0.084,
    mp_starty=0.14,
    mp_width=0.84,
    mp_height=0.75,
    mp_rowgap=0.1,
    mp_colgap=0.18,
    num_rows=1,
    num_cols=2,
)
mp_layout_dict = asdict(mp_layout)

# Style
border_width = 11
line_width = 0.5
boxwidth = 0.75

# Font
font_dict = asdict(font)

# Offset
offset.ylabel_offset = "1.2,0"
offset_dict = asdict(offset)

plot_script = base_preset.format(root_dir=root_dir, width=width, height=height, output=output)
plot_script += base_mp_layout.format(**mp_layout_dict)
plot_script += base_style.format(border_width=border_width, line_width=line_width, boxwidth=boxwidth)
plot_script += base_font.format(**font_dict)
plot_script += base_offset.format(**offset_dict)

plot_script += """
set style fill pattern
"""

off = 0.7
basic = 0.8

# Fist subplot
plot_script += base_next_plot.format(title="(a)")
plot_script += """
set boxwidth 0.5 absolute
set key at -5.5,3.85 maxrows 1
set xtics noenhanced
set xtics add ('' -5, '' -4, 'I/O-intensive' -3, '' -2, '' -1, '' 0, '' 1, '' 2, 'Compute-intensive' 3, '' 4, '' 5)
set y2tics
set y2tics font "Times New Roman,12" offset -0.8,0
set xrange [-5:5]
set ylabel "Throughput (GB/s)"
set y2label "Batch kops per second"
set y2label font "Times New Roman,12" offset -2,0
set yrange [0:]
set y2range [0:]
"""
plot_script += f"plot \"{data_files[0]}\" \\"
base = baselines[0]
plot_script += base_y1_bar.format(
    row=base.id,
    entry=f"($0 - ({basic} + {len(baselines) - base.id} * {off})):($2 / 1000)",
    color=base.color,
    pattern=base.pattern,
    title=base.title,
)
for base in baselines[1:2]:
    curve = base_y1_bar.format(
        row=base.id,
        entry=f"($0 - ({basic} + {len(baselines) - base.id} * {off})):($2 / 1000)",
        color=base.color,
        pattern=base.pattern,
        title=base.title,
    )
    plot_script += "'' \\" + curve
for base in baselines[2:]:
    curve = base_y1_bar_notitle.format(
        row=base.id,
        entry=f"($0 - ({basic} + {len(baselines) - base.id} * {off})):($2 / 1000)",
        color=base.color,
        pattern=base.pattern,
    )
    plot_script += "'' \\" + curve
for base in baselines:
    curve = base_y2_bar.format(
        row=base.id + len(baselines),
        entry=f"($0 + ({basic} + {base.id} * {off})):($2 / 1000)",
        color=base.color,
        pattern=base.pattern,
    )
    plot_script += "'' \\" + curve

# Second plot
plot_script += base_next_plot.format(title="(b)")
plot_script += """
set xtics noenhanced
set xtics add ('' -3, 'Throughput' -2.5, 'Latency' 2, '' 3)
set y2tics add ('' 30, '3500' 35, '4000' 40)
set ylabel "Throughput (GB/s)"
set y2label "Latency (us)"
set key at -4.6,0.988 maxrows 1

set arrow from 1.5,0.665 to 2.5,0.665 nohead lc rgb "white" lw 1.5 front
set arrow from 1.5,0.675 to 2.5,0.675 nohead lc rgb "white" lw 1.5 front
set arrow from 1.5,0.685 to 2.5,0.685 nohead lc rgb "white" lw 1.5 front
set arrow from 4.75,0.675 to 5,0.675 nohead lc rgb "white" lw 1.5 front
set arrow from 4.81,0.673 to 5.16,0.688 nohead lc rgb "black" lw 0.5 front
set arrow from 4.81,0.663 to 5.16,0.678 nohead lc rgb "black" lw 0.5 front
"""
plot_script += f'plot "{data_files[1]}" \\'
base = baselines[0]
plot_script += base_y1_bar_notitle.format(
    row=base.id,
    entry=f"($0 - ({basic} + {len(baselines) - base.id} * {off})):($2 / 1000)",
    color=base.color,
    pattern=base.pattern,
)
for base in baselines[1:2]:
    curve = base_y1_bar_notitle.format(
        row=base.id,
        entry=f"($0 - ({basic} + {len(baselines) - base.id} * {off})):($2 / 1000)",
        color=base.color,
        pattern=base.pattern,
    )
    plot_script += "'' \\" + curve
for base in baselines[2:]:
    curve = base_y1_bar.format(
        row=base.id,
        entry=f"($0 - ({basic} + {len(baselines) - base.id} * {off})):($2 / 1000)",
        color=base.color,
        pattern=base.pattern,
        title=base.title,
    )
    plot_script += "'' \\" + curve
for base in baselines:
    curve = base_y2_bar.format(
        row=base.id + len(baselines),
        entry=f"($0 + ({basic} + {base.id} * {off})):2",
        color=base.color,
        pattern=base.pattern,
        title=base.title,
    )
    plot_script += "'' \\" + curve

with tempfile.NamedTemporaryFile(mode="w+", suffix=".gp") as f:
    f.write(plot_script)
    f.flush()
    subprocess.run(["gnuplot", f.name], env=env)
